import React from 'react';
import { Link } from 'react-router-dom';

const About = () => {
  return (
    <div>
        <Link to="work">Work</Link> 
    </div>
  );
};

export default About;
