import React from 'react';
import './App.css';
import styled from 'styled-components';
import Header from "./components/Header";
import pic from "./components/Image/img1.jpg";



function App() {
  return (
    <div className="App">
      <Header/>
      <div>
      <div className='Box' >
       </div>
       <img className='Photo' src={pic} />
       
       </div>
      
    </div>  
  )
}

export default App;
